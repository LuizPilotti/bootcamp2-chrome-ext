# bootcamp2-chrome-ext-LuanJywago

Notas Rápidas
Extensão simples (Manifest V3) para salvar notas rápidas no navegador.

Instalação manual

1. Acesse chrome://extensions;
  <img width="810" height="117" alt="image" src="https://github.com/user-attachments/assets/93cbb402-9acb-43b2-9d1b-295d43a1ca44" />

   
2. Ative Developer mode;
  <img width="962" height="53" alt="image" src="https://github.com/user-attachments/assets/7ded6fe3-4e53-4c5f-a4a3-b19fc4523ae4" />


3. Clique em Load unpacked e selecione a pasta da extensão;
  <img width="509" height="110" alt="image" src="https://github.com/user-attachments/assets/e74bc7c4-8cf2-4069-9ed0-6b0835cf8e79" />


4. Quando selecionar a pasta BOOTCAMP_EXTENSION, selecione em seguida a extension_bootcamp;
  <img width="303" height="22" alt="image" src="https://github.com/user-attachments/assets/f400ac0e-94f7-456e-91a7-350dec3515d7" />


5. Para funcionar, a área de extensões precisa do documento manifest.json na pasta correta;
  <img width="325" height="33" alt="image" src="https://github.com/user-attachments/assets/dc12c13f-a3cd-4ec6-b917-8db72913fb34" />

6. Se caso precisar de Key para compactar a extensão, selecione ela em: Arquivo de chaves particulares (opcional);

7. Depois de fazer isso, a extensão já estará disponível, mas para visualizá-la, acesse "Carregar sem compactação" e selecione a mesma pasta informada anteriormente no passo 5;

8. Foto de visuzalização correta;
  <img width="428" height="140" alt="image" src="https://github.com/user-attachments/assets/a9ddd6d2-afc6-4cbe-bf42-5d8dd7de2d86" />

9. Obrigado por utilizar a extensão!

10. Para caso de dúvidas, estou a disposição.

   

